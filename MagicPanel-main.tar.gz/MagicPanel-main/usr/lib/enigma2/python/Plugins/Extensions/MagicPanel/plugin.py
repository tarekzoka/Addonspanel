import socket
from Plugins.Plugin import PluginDescriptor
from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Button import Button
from Components.Pixmap import Pixmap
from enigma import eConsoleAppContainer
from Screens.MessageBox import MessageBox

PLUGIN_ICON = "icon.png"
PLUGIN_VERSION = "5.0"

class ProgressScreen(Screen):
    skin = """
    <screen name="ProgressScreen" position="center,center" size="640,220" title="Progressing please wait...">
        <widget name="progress_label" position="10,10" size="590,40" font="Regular;18" foregroundColor="#00f2e0" halign="center" />
        <widget name="progress_bar" position="10,50" size="600,25" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/HamdyAhmed_Panelv5/icons/bar.png" zPosition="2" alphatest="on" borderWidth="1" />
        <widget name="status" position="10,80" size="590,35" font="Regular;14" halign="center" />
        <widget name="cancel_button" position="200,130" size="200,40" font="Regular;18" halign="center" foregroundColor="##00f2e0" backgroundColor="#9F1313" />
    </screen>
    """

    def __init__(self, session, command, title):
        self.session = session
        Screen.__init__(self, session)
        self.command = command
        self.title = title
        self.container = eConsoleAppContainer()
        self.container.appClosed.append(self.command_finished)
        self.container.dataAvail.append(self.command_output)
        self["status"] = Label(f"Installing: {self.title}...")
        self["progress_label"] = Label(title)
        self["progress_bar"] = Pixmap()
        self["cancel_button"] = Button("Cancel")
        self.run_command()

    def run_command(self):
        if self.container.execute(self.command):
            self["status"].setText(f"Failed to execute: {self.command}")

    def command_output(self, data):
        pass

    def command_finished(self, retval):
        self.session.openWithCallback(
            self.on_close_messagebox,
            MessageBox,
            f"{self.title} installation completed.",
            MessageBox.TYPE_INFO,
            timeout=5,
        )

    def on_close_messagebox(self, result):
        self.close()

class MagicPanel(Screen):
    skin = """
    <screen name="MagigPanelv5" position="156,159" size="1600,750" title="MagicPanel-v5">
    <widget name="main_menu" position="278,20" size="405,622" scrollbarMode="showOnDemand" itemHeight="45" font="Regular;26" />
    <widget name="status" position="323,667" size="673,30" transparent="1" font="Regular;20" halign="center" />
    <widget name="key_red" position="276,706" size="185,25" font="Regular;18" halign="center" backgroundColor="#B22222" />
    <widget name="key_green" position="474,706" size="185,25" font="Regular;18" halign="center" backgroundColor="#6400" />
    <widget name="key_yellow" position="671,706" size="185,25" font="Regular;18" halign="center" backgroundColor="#B8860B" />
    <widget name="key_blue" position="866,706" size="185,25" font="Regular;18" halign="center" backgroundColor="#8b" />
    <widget source="global.CurrentTime" render="Label" position="1398,701" size="210,52" font="Regular; 28" halign="center" foregroundColor="gold" backgroundColor="#160000" transparent="1" zPosition="6">
    <convert type="ClockToText">Format:%d.%m.%Y</convert>
    </widget>
    <widget font="Regular;30" foregroundColor="gold" backgroundColor="#160000" halign="center" position="1430,655" render="Label" size="143,52" source="global.CurrentTime" transparent="1" valign="center" zPosition="5">
    <convert type="ClockToText">Default</convert>
    </widget>
    <widget name="background1" position="20,25" size="250,600" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MagicPanel/icons/background1.png" zPosition="1" alphatest="on" />
    <widget name="sub_menu" position="695,20" size="876,622" scrollbarMode="showOnDemand" itemHeight="45" backgroundColor="#000000" font="Regular;26" />
    </screen>
    """

    def __init__(self, session):
        self.session = session
        Screen.__init__(self, session)

        self.main_menu = ["1.  MyPanel", "2.  Update the panel", "3.  Skins", "4.  Free", "5.  Novaler", "6.  Channels", "7.  plugins", "8.  Ajpanel", "9.  EPG", "10. Others-Panel", "11. Cam-Emulator", "12. Backup-build", "13. Iptv-player", "14. Audio-files", "15. Picons", "16. Tools", "17. Multiboot", "18. remove", "19. Bootlogo All", "20. Fix-IT",]
        self.sub_menus = {
            "1.  MyPanel": [
        ("1.  install panel version 5", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/1New-Ajpanel-Panel-v5.0_HAN.sh -O - | /bin/sh"),
        ],
           "2.  Update the panel": [
        ("Update My panel", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/New-update.sh -O - | /bin/sh"),
            ],
            "3.  Skins": [
        ("1.   YouViX_New-Skin_PosterX_4x1..........openvix 6.6.013", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/youvix/skins-youVix-Mod_H-Ahmed.sh -O - | /bin/sh"),
        ("2.   YouViX_Skin_PosterX_4x1..............openvix py 3.12", "wget https://raw.githubusercontent.com/Ham-ahmed/Skin-py3-12-2/main/YouViX-Skin6_5_003-PosterX_4x1-Mod-HA.sh -O - | /bin/sh"),
        ("3.   YouViX_Skin_PosterX_4x1...............openvix6.5.001", "wget https://raw.githubusercontent.com/Ham-ahmed/Skins2024/main/YouViX-Skin_PosterX_4x1-Mod-HAhmed.sh -O - | /bin/sh"),
        ("4.   E2-DarkOS_posterX....................openvix py 3.12", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/E2-DarkOS_posterX-Mod_HAhmed.sh -O - | /bin/sh"),
        ("5.   premium-fhd-black....................openvix py 3.12", "wget https://gitlab.com/eliesat/skins/-/raw/main/all/premium-fhd/premium-fhd-black.sh -O - | /bin/sh"),
        ("6.   estuaryFHD-posterX-v.5.......openspa_MOD-HA_py3.12.4", "wget https://raw.githubusercontent.com/Ham-ahmed/openspa/main/estuaryHD_openspa-posterX-v.5-mod-HAhmed.sh -O - | /bin/sh"),
        ("7.   openplusFHD_posterX-v2........openspa8.3.006-MOD-H-A", "wget https://raw.githubusercontent.com/Ham-ahmed/openspa/main/openplusFHD_posterX-v2_Mod-H-Ahmed.sh -O - | /bin/sh"),
        ("8.   BlackSPAFHD_posterX...........openspa8.3.006-MOD-H-A", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/BlackSPAFHD_posterX-Mod_HAhmed.sh -O - | /bin/sh"),
        ("9.   openplusFHD_posterX...........openspa8.3.006-MOD-H-A", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/openplusFHD_posterX-Mod_HAhmed.sh -O - | /bin/sh"),
        ("10.  PLi-FullNightFHD-v1.0..H_Ahmed-py3.13-foxbob-Gcc14.2", "wget https://raw.githubusercontent.com/Ham-ahmed/pli/refs/heads/main/PLi-FullNightFHD_v1.0-Mod-HA.sh -O - | /bin/sh"),
        ("11.  AglareFHD_4.6-openpli.....................SKIN-MNasr", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/Aglaer/Aglare-FHD-pli_4.6.sh -O - | /bin/sh"),
        ("12.  MaxyFHD_1.0-openpli3.12.4.................SKIN-MNasr", "wget https://raw.githubusercontent.com/Ham-ahmed/Skins2024/main/1skins-maxy-fhd-pli_1.0_all.sh -O - | /bin/sh"),
        ("13.  MX_LiveFHD_posterX-v4_New...........openBH_5.4.1.003", "wget https://raw.githubusercontent.com/Ham-ahmed/Skins2024/main/MX-LiveFHD-posterX_v4-mod-HAhmed.sh -O - | /bin/sh"),
        ("14.  MX_LiveFHD_posterX-v3_New...........openBH_5.4.1.002", "wget https://raw.githubusercontent.com/Ham-ahmed/BH-Skins/main/MX-LiveFHD-posterX-v3_mod-HAhmed.sh -O - | /bin/sh"),
        ("15.  oDreamyFHD_mini-posterX-v2-10.5r1-2-3-4.......Mod-HA", "wget https://raw.githubusercontent.com/Ham-ahmed/oDreamy-mini/main/oDreamyFHD_mini-posterX-v2_Mod_HAhmed.sh -O - | /bin/sh"),
        ("16.  oDreamyFHD_mini-posterX-10.5r1-2-3............Mod-HA", "wget https://raw.githubusercontent.com/Ham-ahmed/Skins2024/main/oDreamyFHD_mini-posterX-Mod_HA.sh -O - | /bin/sh"),
        ("17.  AglareFHD_v.4.7-Atv-egami-spa..................MNasr", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/Aglaer/Aglare-FHD-4.7.sh -O - | /bin/sh"),
        ("18.  xDreamyFHD_v.3.8-Atv-egami-spa..............MHussein", "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/xdreamy/skins-xDreamy-v3.8.sh -O - | /bin/sh"),
        ("19.  esturyFHD-pure2-7.4-py3.12.2..................Mod-HA", "wget https://raw.githubusercontent.com/Ham-ahmed/Skin-py3-12-2/main/estuaryfhd-posterX-mod3_H-Ahmed.sh -O - | /bin/sh"),
        ("20.  XionFHD-Skin posterX-v02_OpenHDF..............Mod-HA", "wget https://raw.githubusercontent.com/Ham-ahmed/XionFHD/main/XionHDF-posterX-v02_Mod_HAhmed.sh -O - | /bin/sh"),
        ("21.  Gigabluepaxv4FHD_3x1-teamblue-7.4-py3.1.......Mod-HA", "wget https://raw.githubusercontent.com/Ham-ahmed/gigablue/refs/heads/main/GigabluePaxV4-Skin3x1_Mod-H-Ahmed.sh -O - | /bin/sh"),
        ("22.  Gigabluepaxv4FHD_3x1-teamblue-7.4-py3.12.4....Mod-HA", "wget https://raw.githubusercontent.com/Ham-ahmed/gigablue/refs/heads/main/GigabluePaxV4-Skin3x1_Mod-H-Ahmed.sh -O - | /bin/sh"),
        ("23.  SatDreamGrFHD-SatDreamGr-10-py3.9.9...........Mod-HA", "wget https://raw.githubusercontent.com/Ham-ahmed/SatDreamGr/main/Satdreamgr-HDF-posterX-v01_Mod_HAhmed.sh -O - | /bin/sh"),
    ],
           "4.  Free": [
        ("1. 205-Portals..............Add 205-Newportals-28122024", "wget https://raw.githubusercontent.com/Ham-ahmed/205/refs/heads/main/205-portals.sh -O - | /bin/sh"),
        ("2. 39-M3u_files_Xklass.............Add 39-New_M3U-Files", "wget https://raw.githubusercontent.com/Ham-ahmed/205/refs/heads/main/39-M3u_files.sh -O - | /bin/sh"),
    ],
          "5.  Novaler": [
        ("1.   novalerstore....py3.12", "wget http://ipk.ath.cx/pg/novalerstore-py3.12.sh -O - | /bin/sh"),
        ("2.   novalerstore....py3-11", "wget http://ipk.ath.cx/pg/novalerstore-py3.11.sh -O - | /bin/sh"),
        ("3.   novalerstore...py3-9.9", "wget http://ipk.ath.cx/pg/novalerstore-py3.9.sh -O - | /bin/sh"),
        ("4.   ipaudioplus.....py3.12", "wget https://raw.githubusercontent.com/Ham-ahmed/Novaler/main/ipaudioplus-py3.12_4.1-r0_all.sh -O - | /bin/sh"),
        ("5.   ipaudioplus.....py3-11", "wget https://raw.githubusercontent.com/Ham-ahmed/Novaler/main/ipaudioplus-py3.11_4.1-r0_all.sh -O - | /bin/sh"),
        ("6.   ipaudioplus....py3-9.9", "wget https://raw.githubusercontent.com/Ham-ahmed/Novaler/main/ipaudioplus-py3.9_4.1-r0_all.sh -O - | /bin/sh"),
        ("7.   ipsat...........py3.12", "wget https://raw.githubusercontent.com/Ham-ahmed/Novaler/main/ipsat-py3.12_9.5-r0_all.sh -O - | /bin/sh"),
        ("8.   ipsat...........py3-11", "wget https://raw.githubusercontent.com/Ham-ahmed/Novaler/main/ipsat-py3.11_9.5-r0_all.sh -O - | /bin/sh"),
        ("9.   ipsat..........py3-9.9", "wget https://raw.githubusercontent.com/Ham-ahmed/Novaler/main/ipsat-py3.9_9.5-r0_all.sh -O - | /bin/sh"),
        ("10.  novacampro......py3.12", "wget http://ipk.ath.cx/pg/novacam-py3.12.sh -O - | /bin/sh"),
        ("11.  novacampro......py3.11", "wget http://ipk.ath.cx/pg/novacam-py3.11.sh -O - | /bin/sh"),
        ("12.  novacampro.......py3.9", "wget http://ipk.ath.cx/pg/novacam-py3.9.sh -O - | /bin/sh"),
        ("13.  beengo..........py3.12", "wget http://ipk.ath.cx/pg/beengo-py3.12.sh -O - | /bin/sh"),
        ("14.  beengo..........py3-11", "wget http://ipk.ath.cx/pg/beengo-py3.11.sh -O - | /bin/sh"),
        ("15.  beengo.........py3-9.9", "wget http://ipk.ath.cx/pg/beengo-py3.9.sh -O - | /bin/sh"),
        ("16.  novalertv.......py3.12", "wget http://ipk.ath.cx/pg/novalertv-py3.12.sh -O - | /bin/sh"),
        ("17.  novalertv.......py3-11", "wget http://ipk.ath.cx/pg/novalertv-py3.11.sh -O - | /bin/sh"),
        ("18.  novalertv......py3-9.9", "wget http://ipk.ath.cx/pg/novalertv-py3.9.sh -O - | /bin/sh"),
        ("19.  novatv..........py3.12", "wget http://ipk.ath.cx/pg/novatv-py3.12.sh -O - | /bin/sh"),
        ("20.  novatv..........py3-11", "wget http://ipk.ath.cx/pg/novatv-py3.11.sh -O - | /bin/sh"),
        ("21.  novatv.........py3-9.9", "wget http://ipk.ath.cx/pg/novatv-py3.9.sh -O - | /bin/sh"),
    ],
          "6.  Channels": [
        ("1.   mohamed-os-motor_01-01-2024", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/channels_backup_Mohamed-OS_01-01-2025.sh -O - | /bin/sh"),
        ("2.   mohamed-os-motor_20-12-2024", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/channels_backup_Mohamed-OS_20-12-2024.sh -O - | /bin/sh"),
        ("3.   mohamed-os-motor_12-12-2024", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/refs/heads/main/channels_backup_20241212_MohamedOS.sh -O - | /bin/sh"),
        ("4.   mohamed-os-motor_29-11-2024", "wget https://raw.githubusercontent.com/Ham-ahmed/212/refs/heads/main/channels_backup_20241229_vhannibal.sh -O - | /bin/sh"),
        ("5.   vhannibal-motor_29-11-2024.", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/refs/heads/main/channels_backup_Mohamed-OS_22-11-2024.sh -O - | /bin/sh"),
        ("6.   ciefp-motor_23-11-2024.....", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/refs/heads/main/channels_backup_20241123_ciefp.sh -O - | /bin/sh"),
        ("7.   mohamed-os-motor_22-11-2024", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/refs/heads/main/channels_backup_Mohamed-OS_22-11-2024.sh -O - | /bin/sh"),
        ("8.   ciefp-motor_17-10-2024.....", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/refs/heads/main/channels_backup_Ciefp_20241017.sh -O - | /bin/sh"),
        ("9.   Samy-A-E-motor_26-9-2024...", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/refs/heads/main/channels_backup_20240924_Samy-A-E.sh -O - | /bin/sh"),
        ("10.  ciefp-motor_15-9-2024......", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_Ciefp_20240915_015044.sh -O - | /bin/sh"),
        ("11.  ciefp-motor_9-9-2024.......", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_20240909_ciefp.sh -O - | /bin/sh"),
        ("12.  Bosnia_Bouquet-16e.........", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/Bosnia_MStream_16e.sh -O - | /bin/sh"),
        ("13.  ciefp-motor_30-8-2024......", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_20240901_ciefp.sh -O - | /bin/sh"),
        ("14.  mohamed-os-motor_18-8-2024.", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_Mohamed-OS_18-08-2024.sh -O - | /bin/sh"),
        ("15.  mohamed-os-motor_8-8-2024..", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_Mohamed-OS_08-08-2024.sh -O - | /bin/sh"),
        ("16.  mohamed-os-motor_4-8-2024..", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_Mohamed-OS_04-08-2024.sh -O - | /bin/sh"),
        ("17.  mohamed-os-motor_21-7-2024.", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_Mohamed-OS_19-7-2024.sh -O - | /bin/sh"),
        ("18.  Mohammed-Nasr_motor6-7.....", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/channels_backup_MNASR_20240706.sh -O - | /bin/sh"),
        ("19.  AHMED-HUSSEIN-15-7_motor...", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_A-Hussein_20240715_141837.sh -O - | /bin/sh"),
        ("20.  mohamed-os-motor_8-7-2024..", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_Mohamed-OS_8-7-2024.sh -O - | /bin/sh"),
        ("21.  Mohammed-Nasr-motor6-7-2024", "wget https://raw.githubusercontent.com/Ham-ahmed/channels-Files/main/channels_backup_MNASR_6-7-2024.sh -O - | /bin/sh"),
    ],
          "7.  plugins": [
        ("1.   History-Zap_1.0.41.....py3.12", "wget https://raw.githubusercontent.com/Ham-ahmed/2412/refs/heads/main/historyzap_1.0.41.sh -O - | /bin/sh"),
        ("2.   historyzap-1.0.42_py3.13_3.12", "wget https://raw.githubusercontent.com/Ham-ahmed/plugins3/refs/heads/main/historyzap_1.0.42_3.13.sh -O - | /bin/sh"),
        ("3.   History_Zap_1.0.38.....py3.12", "wget https://raw.githubusercontent.com/biko-73/History_Zap_Selector/main/installer.sh -O - | /bin/sh"),
        ("4.   wireguard-vpn........13.9_New", "wget https://raw.githubusercontent.com/Ham-ahmed/2412/refs/heads/main/wireguard-vpn_13.9.sh -O - | /bin/sh"),
        ("5.   wireguard-vpn............13.0", "wget https://raw.githubusercontent.com/Ham-ahmed/212/refs/heads/main/wireguard-vpn_13.0_all.sh -O - | /bin/sh"),
        ("6.   oaweather3.2.................", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/oaweather_3.2.sh -O - | /bin/sh"),
        ("7.   oaweather3.2.1...............", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/main/oaweather_3.2.1_all.sh -O - | /bin/sh"),
        ("8.   oaweather2.6.................", "wget https://raw.githubusercontent.com/Ham-ahmed/1New-P/main/oaweather.sh -O - | /bin/sh"),
        ("9.   weather-plugin...........v2.1", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/main/weatherplugin_2.1_all.sh -O - | /bin/sh"),
        ("10.  weatherplugin................", "wget https://raw.githubusercontent.com/Ham-ahmed/1New-P/main/weather_plugin.sh -O - | /bin/sh"),
        ("11.  TheWeather...................", "wget https://raw.githubusercontent.com/biko-73/TheWeather/main/installer.sh -O - | /bin/sh"),
        ("12.  weatherplugin-py2-py3........", "wget https://raw.githubusercontent.com/Ham-ahmed/Iptv-plugin/refs/heads/main/theweather-py2-py3_2.4_r1.sh -O - | /bin/sh"),
        ("13.  weatherplugin................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/weatherplugin/weatherplugin.sh -O - | /bin/sh"),
        ("14.  weatherplugin..........vector", "wget https://gitlab.com/eliesat/extensions/-/raw/main/weatherplugin-vector/weatherplugin-vector.sh -O - | /bin/sh"),
        ("15.  theweather...................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/theweather/theweather.sh -O - | /bin/sh"),
        ("16.  youtube...........py3-git1249", "wget https://raw.githubusercontent.com/Ham-ahmed/2412/refs/heads/main/youtube_py3-git1249.sh -O - | /bin/sh"),
        ("17.  youtube............py3-git240", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/youtube_py3-git1240.sh -O - | /bin/sh"),
        ("18.  youtube...........py3-git1231", "wget https://raw.githubusercontent.com/Ham-ahmed/plugins3/refs/heads/main/youtube_py3-git1231.sh -O - | /bin/sh"),
        ("19.  footonsat..............1.9.r0", "wget https://raw.githubusercontent.com/Ham-ahmed/Iptv-plugin/refs/heads/main/footonsat_1.9-r0.sh -O - | /bin/sh"),
        ("20.  footonsat....................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/footonsat/footonsat.sh -O - | /bin/sh"),
        ("21.  footonsat..............1.6.r0", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/main/footonsat_1.9-r0_all.sh -O - | /bin/sh"),
        ("22.  bootlogoswapper..........v2.4", "wget https://raw.githubusercontent.com/Ham-ahmed/plugins3/refs/heads/main/bootlogoswapper_v2.4.sh -O - | /bin/sh"),
        ("23.  crashlogviewer............1.5", "wget https://raw.githubusercontent.com/Ham-ahmed/plugins3/refs/heads/main/crashlogviewer_1.5.sh -O - | /bin/sh"),
        ("24.  crashlogviewer............1.3", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/main/crashlogviewer_1.3_all.sh -O - | /bin/sh"),
        ("25.  filecommander............2024", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/main/filecommander_mod_2024_by_lululla_all.sh -O - | /bin/sh"),
        ("26.  alternativesoftcammanager....", "wget https://gitlab.com/eliesat/extensions/-/raw/main/alternativesoftcammanager/alternativesoftcammanager.sh -O - | /bin/sh"),
        ("27.  athantimes...................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/athantimes/athantimes.sh -O - | /bin/sh"),
        ("28.  bissfeedautokey..............", "wget https://gitlab.com/eliesat/extensions/-/raw/main/bissfeedautokey/bissfeedautokey.sh -O - | /bin/sh"),
        ("29.  bitrate2.0...................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/bitrate/bitrate.sh -O - | /bin/sh"),
        ("30.  bouquetmakerxtream...........", "wget https://gitlab.com/eliesat/extensions/-/raw/main/bouquetmakerxtream/bouquetmakerxtream.sh -O - | /bin/sh"),
        ("31.  cacheflush...................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/cacheflush/cacheflush.sh -O - | /bin/sh"),
        ("32.  crondmanager.................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/crondmanager/crondmanager.sh -O - | /bin/sh"),
        ("33.  easy-cccam...................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/easy-cccam/easy-cccam.sh -O - | /bin/sh"),
        ("34.  epggrabber...................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/epggrabber/epggrabber.sh -O - | /bin/sh"),
        ("35.  feedsfinder..................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/feedsfinder/feedsfinder.sh -O - | /bin/sh"),
        ("36.  freeserver...................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/freeserver/freeserver.sh -O - | /bin/sh"),
        ("37.  internet-speed-test..........", "wget https://gitlab.com/eliesat/extensions/-/raw/main/internetspeedtest/internet-speed-test.sh -O - | /bin/sh"),
        ("38.  ipaudio-6.8..................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/ipaudio/ipaudio.sh -O - | /bin/sh"),
        ("39.  ipaudiopro-1.1....py-3.9-3.11", "wget https://gitlab.com/eliesat/extensions/-/raw/main/ipaudiopro/ipaudiopro.sh -O - | /bin/sh"),
        ("40.  ipchecker....................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/ipchecker/ipchecker.sh -O - | /bin/sh"),
    ],
          "8.  Ajpanel": [
        ("1.   ajpanel-v10.4...", "wget https://raw.githubusercontent.com/biko-73/AjPanel/main/installer.sh -O - | /bin/sh"),
        ("2.   ajpanel-v10.2.3.", "wget https://raw.githubusercontent.com/Ham-ahmed/Ajpanel/refs/heads/main/plugin-ajpanel_v10.2.3.sh-O - | /bin/sh"),
        ("3.   ajpanel-v10.2.2.", "wget https://raw.githubusercontent.com/Ham-ahmed/Ajpanel/refs/heads/main/plugin-ajpanel_v10.2.2.sh -O - | /bin/sh"),
        ("4.   ajpanel-v10.2.0.", "wget https://raw.githubusercontent.com/Ham-ahmed/212/refs/heads/main/ajpanel_v10.2.0_all.sh -O - | /bin/sh"),
        ("5.   ajpanel-v10.1.0.", "wget https://raw.githubusercontent.com/biko-73/AjPanel/main/installer.sh -O - | /bin/sh"),
        ("6.   ajpanel-v10.0.0.", "wget https://raw.githubusercontent.com/biko-73/AjPanel/main/installer.sh -O - | /bin/sh"),
        ("7.   ajpanel-v9.4.0..", "wget https://raw.githubusercontent.com/Ham-ahmed/Ajpanel/main/plugin-extensions-ajpanel_v9.4.0.sh -O - | /bin/sh"),
        ("8.   ajpanel-v9.3.0 .", "wget https://raw.githubusercontent.com/Ham-ahmed/Ajpanel/main/plugin-extensions-ajpanel_v9.3.0_all.sh -O - | /bin/sh"),
        ("9.   ajpanel-v9.1.0..", "wget https://raw.githubusercontent.com/Ham-ahmed/Ajpanel/main/plugin-extensions-ajpanel_v9.1.0_all.sh -O - | /bin/sh"),
        ("10.  ajpanel-v9.0.0..", "wget https://raw.githubusercontent.com/Ham-ahmed/Ajpanel/main/plugin-extensions-ajpanel_v9.0.0_all.sh -O - | /bin/sh"),
     ],
          "9.  EPG": [
        ("1.   EpgGrabber-24.2............", "wget https://raw.githubusercontent.com/ziko-ZR1/Epg-plugin/master/Download/installer.sh -O - | /bin/sh"),
        ("2.   EpgGrabber-23.7............", "wget https://raw.githubusercontent.com/ziko-ZR1/Epg-plugin/master/Download/installer.sh -O - | /bin/sh"),
        ("3.   EpgGrabber-23.4............", "wget https://raw.githubusercontent.com/Ham-ahmed/newp/main/Epg-plugin-master-v23.4.sh -O - | /bin/sh"),
        ("4.   EpgGrabber-22.9............", "wget https://raw.githubusercontent.com/ziko-ZR1/Epg-plugin/master/Download/installer.sh -O - | /bin/sh"),
        ("5.   epgimport-1.9.1............", "opkg install enigma2-plugin-extensions-epgimport</item> -O - | /bin/sh"),
        ("6.   subssupport-v1.7.0-r10.....", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.sh -O - | /bin/sh"),
        ("7.   subssupport-v1.7.0-r8......", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/subssupport-1.1.0-r8-install.sh -O - | /bin/sh"),
        ("8.   newvirtualkeyboard_Subsport", "wget https://raw.githubusercontent.com/fairbird/NewVirtualKeyBoard/main/subsinstaller.sh -O - | /bin/sh"),
        ("9.   TMBD_8.6-r7_py 3.11-12.....", "wget https://raw.githubusercontent.com/Ham-ahmed/plugins3/refs/heads/main/TMBD_8.6-r7.sh -O - | /bin/sh"),
        ("10.  subssupport-v1.7.0-r7......", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/refs/heads/main/subssupport-install.sh -O - | /bin/sh"),
        ("11.  subssupport-v1.7.0 r6......", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.sh -O - | /bin/sh"),
        ("12.  subssupport-v1.7.0 r5......", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.sh -O - | /bin/sh"),
        ("13.  subssupport-By_Mora Hosny..", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.sh -O - | /bin/sh"),
        ("14.  subssupport-By_Mora Hosny..", "wget https://raw.githubusercontent.com/Ham-ahmed/subsupport/main/SubsSupport.sh -O - | /bin/sh"),
        ("15.  subssupport-3.12.1.........", "wget https://raw.githubusercontent.com/Ham-ahmed/subsupport/main/SubsSupport.sh -O - | /bin/sh"),
        ("16.  jediepgxtream_2.12.........", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.sh -O - | /bin/sh"),
        ("17.  xtraevent_6.802............", "wget https://raw.githubusercontent.com/Ham-ahmed/plugins2/refs/heads/main/jediepgxtream_2.12.sh -O - | /bin/sh"),
        ("18.  EPGTranslator..............", "wget https://raw.githubusercontent.com/Ham-ahmed/plugins2/refs/heads/main/xtraevent_6.802_all.sh -O - | /bin/sh"),
        ("19.  xtraevent_6.801............", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/EPGTranslator-plugin.sh -O - | /bin/sh"),
        ("20.  xtraevent_6.8..............", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/refs/heads/main/xtraevent_6.801_all.sh -O - | /bin/sh"),
        ("21.  xtraevent_6.798............", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/refs/heads/main/xtraevent_6.8_all.sh -O - | /bin/sh"),
        ("22.  xtraevent-v6.7.............", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/refs/heads/main/xtraevent_6.798_all.sh -O - | /bin/sh"),
        ("23.  xtraevent-v6.6.............", "wget https://github.com/Ham-ahmed/xtra/blob/main/xtraevent-plugin_v6.7.sh -O - | /bin/sh"),
        ("24.  xtraevent-v6.2.............", "wget https://raw.githubusercontent.com/Ham-ahmed/xtra/main/xtraevent-plugin_v6.6.sh -O - | /bin/sh"),
        ("25.  xtraevent5.3...............", "wget https://raw.githubusercontent.com/Ham-ahmed/EPG/main/xtraEvent_v6.2.sh -O - | /bin/sh"),
        ("26.  xtraevent4.5...............", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/xtraevent-5.3.sh -O - | /bin/sh"),
        ("27.  xtraevent5.2...............", "wget https://gitlab.com/eliesat/extensions/-/raw/main/xtraevent/xtraevent-4.5.sh-O - | /bin/sh"),
        ("28.  jedimakerxtream............", "wget https://gitlab.com/eliesat/extensions/-/raw/main/xtraevent/xtraevent-5.3.sh -O - | /bin/sh"),
        ("29.  Tmbd-v.1.0.9_py 3.11.4-5...", "wget https://gitlab.com/eliesat/extensions/-/raw/main/jedimakerxtream/jedimakerxtream.sh -O - | /bin/sh"),
        ("30.  Tmbd-v.8.6_py 3.11.2.......", "wget https://raw.githubusercontent.com/Ham-ahmed/EPG/refs/heads/main/tmdb_1.0.9_all.sh -O - | /bin/sh"),
    ],
          "10. Others-Panel": [
        ("1.   levi45-addon...manager10.1r27", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/Levi45%20Addons%20Panel%2010.1-r27.sh -O - | /bin/sh"),
        ("2.   levi45-multicammanager10.1r33", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/levi45multicammanager_10.1-r33.sh -O - | /bin/sh"),
        ("3.   oscam-emu-levi45....11865-802", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/oscam-emu-levi45_11865-802.sh -O - | /bin/sh"),
        ("4.   oscam-emu-levi45....11862-802", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/oscam-emu-levi45_11862-802.sh -O - | /bin/sh"),
        ("5.   oscam-emu-levi45....11861-802", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/oscam-emu-levi45_11861-802.sh -O - | /bin/sh"),
        ("6.   oscam-emu-levi45....11860-802", "wget https://raw.githubusercontent.com/Ham-ahmed/oscam11860/refs/heads/main/oscam-emu-levi45_11860-802.sh -O - | /bin/sh"),
        ("7.   oscam-emu-levi45....11858-802", "wget https://raw.githubusercontent.com/Ham-ahmed/Levi45/refs/heads/main/oscam-emu-levi45_11858-802.sh -O - | /bin/sh"),
        ("8.   oscam-emu-levi45....11856-802", "wget https://raw.githubusercontent.com/Ham-ahmed/others2/refs/heads/main/oscam-emu-levi45_11856-802.sh -O - | /bin/sh"),
        ("9.   oscam-emu-levi45....11854-802", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/oscam-emu-levi45_11854-802.sh -O - | /bin/sh"),
        ("10.  oscam-emu-levi45....11849-802", "wget https://raw.githubusercontent.com/Ham-ahmed/others2/refs/heads/main/oscam-emu-levi45_11849-802.sh -O - | /bin/sh"),
        ("11.  oscam-emu-levi45....11847-802", "wget https://raw.githubusercontent.com/Ham-ahmed/others2/refs/heads/main/oscam-emu-levi45_11847-802.sh -O - | /bin/sh"),
        ("12.  oscamicamnew....11863-ICAMEMU", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/oscamicamnew_11863-ICAMEMU-Kitte888.sh -O - | /bin/sh"),
        ("13.  oscamicamnew....11857-ICAMEMU", "wget https://raw.githubusercontent.com/Ham-ahmed/Levi45/refs/heads/main/oscamicamnew_11857-ICAMEMU-Kitte888.sh -O - | /bin/sh"),
        ("14.  oscamicamnew....11847-ICAMEMU", "wget https://raw.githubusercontent.com/Ham-ahmed/others2/refs/heads/main/oscamicamnew_11847-ICAMEMU-Kitte888.sh -O - | /bin/sh"),
        ("15.  oscam-emu-levi45....11845-802", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/oscam-emu-levi45_11845-802.sh -O - | /bin/sh"),
        ("16.  oscamicamnew....11845-ICAMEMU", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/oscamicamnew_11845-ICAMEMU-Kitte888.sh -O - | /bin/sh"),
        ("16.  CiefpsettingsPanel-v.2.......", "wget https://raw.githubusercontent.com/Ham-ahmed/141/refs/heads/main/installer.sh -O - | /bin/sh"),
    ],
          "11. Cam-Emulator": [
        ("1.   Ncam-emu_v15.2-r0........fairman", "wget https://raw.githubusercontent.com/Ham-ahmed/2412/refs/heads/main/ncam_15.2-r0_all.sh -O - | /bin/sh"),
        ("2.   Ncam-emu_v15.1-r0........fairman", "wget https://raw.githubusercontent.com/Ham-ahmed/softcam-emu/refs/heads/main/ncam_15.1-r0_all.sh -O - | /bin/sh"),
        ("3.   oscam-emu_11865-802....audi06-19", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/oscam-11865-emu-802_audi06_19.sh -O - | /bin/sh"),
        ("4.   oscam-emu_11866.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/141/refs/heads/main/oscam_11866-emu-r802.sh -O - | /bin/sh"),
        ("5.   power-11866...........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/141/refs/heads/main/powercam-oscam_11866-emu-r802.sh -O - | /bin/sh"),
        ("6.   supcam-11866..........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/141/refs/heads/main/supcam-oscam_11866-emu-r802.sh -O - | /bin/sh"),
        ("7.   ultaracam-11866.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/141/refs/heads/main/ultracam-oscam_11866-emu-r802.sh -O - | /bin/sh"),
        ("8.   gosatplus-oscam_11866_mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/141/refs/heads/main/gosatplus-oscam_11866-emu-r802.sh -O - | /bin/sh"),
        ("9.   oscam-emu_11865.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/oscam_11865-emu-r802.sh -O - | /bin/sh"),
        ("10.   power-11865..........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/powercam-oscam_11865-emu-r802.sh -O - | /bin/sh"),
        ("11.   supcam-11865.........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/supcam-oscam_11865-emu-r802.sh -O - | /bin/sh"),
        ("12.   ultaracam-11865......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/ultracam-oscam_11865-emu-r802.sh -O - | /bin/sh"),
        ("13.   gosatplus-oscam11865_mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/gosatplus-oscam_11865-emu-r802.sh -O - | /bin/sh"),
        ("14.   oscam-emu_11863-802...audi06-19", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/oscam-11863-emu-802_audi06_19.sh -O - | /bin/sh"),
        ("15.  oscam-emu_11863.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/oscam_11863-emu-r802.sh -O - | /bin/sh"),
        ("16.  power-11863...........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/powercam-oscam_11863-emu-r802.sh -O - | /bin/sh"),
        ("17.  supcam-11863..........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/supcam-oscam_11863-emu-r802.sh -O - | /bin/sh"),
        ("18.  ultaracam-11863.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/ultracam-oscam_11863-emu-r802.sh -O - | /bin/sh"),
        ("19.  gosatplus-oscam_11863_mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/11863/refs/heads/main/gosatplus-oscam_11863-emu-r802.sh -O - | /bin/sh"),
        ("20.  oscam-emu_11862-802....audi06-19", "wget https://raw.githubusercontent.com/Ham-ahmed/Others/refs/heads/main/oscam-emu_11862-802-arm-mips_audi06-19.sh -O - | /bin/sh"),
        ("21.  oscam-emu_11860.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/oscam11860/refs/heads/main/oscam_11860-emu-r802.sh -O - | /bin/sh"),
        ("22.  power-11860...........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/oscam11860/refs/heads/main/powercam-oscam_11860-emu-r802.sh -O - | /bin/sh"),
        ("23.  supcam-11860..........mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/oscam11860/refs/heads/main/supcam-oscam_11860-emu-r802.sh -O - | /bin/sh"),
        ("24.  ultaracam-11860.......mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/oscam11860/refs/heads/main/ultracam-oscam_11860-emu-r802.sh -O - | /bin/sh"),
        ("25.  gosatplus-oscam_11860_mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/oscam11860/refs/heads/main/gosatplus-oscam_11860-emu-r802.sh -O - | /bin/sh"),
    ],
          "12. Backup-build": [
        ("1.   ajpanel-v10.2.0...............All", "wget https://raw.githubusercontent.com/Ham-ahmed/212/refs/heads/main/ajpanel_v10.2.0_all.sh -O - | /bin/sh"),
        ("2.   ArabicSavior..............For All", "wget https://raw.githubusercontent.com/fairbird/ArabicSavior/main/installer.sh -O - | /bin/sh"),
        ("3.   EpgGrabber-23.7...............All", "wget https://raw.githubusercontent.com/ziko-ZR1/Epg-plugin/master/Download/installer.sh -O - | /bin/sh"),
        ("4.   EpgGrabber-23.5...............All", "wget https://raw.githubusercontent.com/Ham-ahmed/EPG/main/epg-plugin-master-v23.5.sh -O - | /bin/sh"),
        ("5.   subssupport-v1.7.0-r10-mora-Mnasr", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.shoplus-py3.11_4.1-r0_all.sh -O - | /bin/sh"),
        ("6.   subssupport-v1.7.0-r7..mora-Mnasr", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/refs/heads/main/subssupport-install.sh -O - | /bin/sh"),
        ("7.   subssupport-v1.7.0 r5..mora-Mnasr", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.sh -O - | /bin/sh"),
        ("8.   subssupport.........By_Mora Hosny", "wget https://github.com/popking159/ssupport/raw/main/subssupport-install.sh  -O - | /bin/sh"),
        ("9.   xtraevent5.3.....................", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/xtraevent-5.3.sh  -O - | /bin/sh"),
        ("10.  Ncam-emu...................v15-r0", "wget https://raw.githubusercontent.com/Ham-ahmed/Ncam15/main/softcams-ncam_V15.0-r0_all.sh -O - | /bin/sh"),
        ("11.  oscam-emu........11812_mohamed-OS", "wget https://raw.githubusercontent.com/Ham-ahmed/11812/main/softcams-oscam_11812-emu-r802_all.sh -O - | /bin/sh"),
        ("12.  keyadder.....................v8.2", "wget https://raw.githubusercontent.com/fairbird/KeyAdder/main/installer.sh -O - | /bin/sh"),
        ("13.  RaedQuickSignal.............v17.4", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/main/RaedQuickSignalv17.4.sh -O - | /bin/sh"),
        ("14.  multi-stalkerpro-v1.2.....openAtv", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/multi-stalkerpro_Atv-py3.-12-8.sh -O - | /bin/sh"),
        ("15.  multistalker-pro.............v1.2", "wget https://raw.githubusercontent.com/Ham-ahmed/backup/main/multistalker-pro_v1.2.sh -O - | /bin/sh"),
        ("16.  multistalker-pro.............v1.1", "wget https://raw.githubusercontent.com/Ham-ahmed/112024/refs/heads/main/multi-stalkerpro_1.1.sh -O - | /bin/sh"),
        ("17.  bouquetmakerxtream...........1.18", "wget https://raw.githubusercontent.com/Ham-ahmed/Iptv-plugin/main/bouquetmakerxtream_pliugin1.18.20240723.sh -O - | /bin/sh"),
        ("18.  Bosnia_ukrania............Package", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/Bosnia_ukrania-MStream.sh -O - | /bin/sh"),
        ("19.  ukrania_Bouquet..............4.9e", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/ukrania_MStream_4.9e.sh -O - | /bin/sh"),
        ("20.  astra-sm-arm..................0.2", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/astra-sm_0.2-r0.sh -O - | /bin/sh"),
        ("21.  ukrania_config...............0109", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/ukrania_config_0109.sh -O - | /bin/sh"),
        ("22.  e2iplayer........................", "wget https://gitlab.com/MOHAMED_OS/e2iplayer/-/raw/main/install-e2iplayer.sh -O - | /bin/sh"),
        ("23.  Xklass-1.10......................", "wget https://raw.githubusercontent.com/Ham-ahmed/newp/main/xklass_v.1-10-30-7-2024.sh -O - | /bin/sh"),
        ("24.  vavoo.......................v1.22", "wget https://raw.githubusercontent.com/Ham-ahmed/newp/main/vavoo_v1.22.sh -O - | /bin/sh"),
        ("25.  iptosat.......................1.8", "wget https://gitlab.com/eliesat/extensions/-/raw/main/iptosat/iptosat.sh -O - | /bin/sh"),
        ("26.  jedimakerxtream..................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/jedimakerxtream/jedimakerxtream.sh -O - | /bin/sh"),
        ("27.  Tmbd-v.8.6..............py 3.11.2", "wget https://raw.githubusercontent.com/biko-73/TMBD/main/installer.sh -O - | /bin/sh"),
        ("28.  Bosnia................Bouquet-16e", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/Bosnia_MStream_16e.sh -O - | /bin/sh"),
        ("29.  astra-sm..................arm-0.2", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/astra-sm_0.2-r0.sh -O - | /bin/sh"),
        ("30.  astra_config.................0507", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/astra_config_050724.sh -O - | /bin/sh"),
        ("31.  History_Zap_1.0.38.........py3.12", "wget https://raw.githubusercontent.com/biko-73/History_Zap_Selector/main/installer.sh -O - | /bin/sh"),
        ("32.  oaweather2.6.....................", "wget https://raw.githubusercontent.com/Ham-ahmed/1New-P/main/oaweather.sh -O - | /bin/sh"),
        ("33.  weather-plugin...............v2.1", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/main/weatherplugin_2.1_all.sh -O - | /bin/sh"),
    ],
              "13. Iptv-player": [
        ("1.   Xklass-1.32............14-01-2025", "wget https://raw.githubusercontent.com/Ham-ahmed/141/refs/heads/main/xklass_1.32-14-01-2025.sh -O - | /bin/sh"),
        ("2.   xstreamity..................v4.72", "wget https://raw.githubusercontent.com/Ham-ahmed/2412/refs/heads/main/xstreamity_4.72.20241223.sh -O - | /bin/sh"),
        ("3.   bouquetmakerxtream..........v1.41", "wget https://raw.githubusercontent.com/Ham-ahmed/Iptv-plugin/refs/heads/main/bouquetmakerxtream_1.41.20241218.sh -O - | /bin/sh"),
        ("4.   vavoo_v1.32...................New", "wget https://raw.githubusercontent.com/Ham-ahmed/plugins3/refs/heads/main/vavoo_1.32.sh -O - | /bin/sh"),
        ("5.   iptosat.......................1.8", "wget https://gitlab.com/eliesat/extensions/-/raw/main/iptosat/iptosat.sh -O - | /bin/sh"),
        ("6.   xcplugin_forever.............v4.3", "wget https://raw.githubusercontent.com/Belfagor2005/xc_plugin_forever/main/installer.sh -O - | /bin/sh"),
        ("7.   jedimakerxtream..................", "wget https://gitlab.com/eliesat/extensions/-/raw/main/jedimakerxtream/jedimakerxtream.sh -O - | /bin/sh"),
        ("8.   multi-stalkerpro-v1.2.....openAtv", "wget https://raw.githubusercontent.com/Ham-ahmed/2125/refs/heads/main/multi-stalkerpro_Atv-py3.-12-8.sh -O - | /bin/sh"),
        ("9.   multistalker-pro.............v1.2", "wget https://raw.githubusercontent.com/Ham-ahmed/backup/main/multistalker-pro_v1.2.sh -O - | /bin/sh"),
        ("10.  multistalker-pro.............v1.1", "wget https://raw.githubusercontent.com/Ham-ahmed/112024/refs/heads/main/multi-stalkerpro_1.1.sh -O - | /bin/sh"),
    ],
         "14. Audio-files": [
        ("1.   Ipaudiopro-1.4...py3.12.4-5-6", "wget https://raw.githubusercontent.com/Ham-ahmed/Plugin/refs/heads/main/ipaudiopro_1.4.sh -O - | /bin/sh"),
        ("2.   Ipaudiopro-1.3.....py3.12.4-5", "wget https://raw.githubusercontent.com/biko-73/ipaudio/main/ipaudiopro.sh -O - | /bin/sh"),
        ("3.   Ipaudiopro....openvix_6.6.001", "wget https://raw.githubusercontent.com/Ham-ahmed/Ipaudio-2024/main/ipaudiopro_1.1-r2.sh -O - | /bin/sh"),
        ("4.   M-Elsaftyv1.1-r6_picons+audio", "wget https://raw.githubusercontent.com/Ham-ahmed/Ipaudio-2024/main/ipaudiopro1.1-r2-Elsafty.sh -O - | /bin/sh"),
        ("5.   Ipaudiopro-v1.1........py3.12", "wget https://raw.githubusercontent.com/Ham-ahmed/Ipaudio-2024/main/ipaudiopro-py3.12_v1.1-By-Zakaria.sh -O - | /bin/sh"),
    ],
         "15. Picons": [
        ("1.   chocholousek......plugin", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/chocholousek-picons_5.0.240904.sh -O - | /bin/sh"),
        ("2.   piconinstaller....plugin", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/piconinstaller_24.08.26_all.sh -O - | /bin/sh"),
        ("3.   picons_All-Sat_30-3-2024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons_All-Sat_28-3-2024.sh -O - | /bin/sh"),
        ("4.   picons-30.0W.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-30.0W_2032024.sh -O - | /bin/sh"),
        ("5.   Nilsat7.0w-8.0w..2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-Nilsat7.0w-8.0w_2032024.sh -O - | /bin/sh"),
        ("6.   picons-7.0W......2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-7.0W_2032024.sh -O - | /bin/sh"),
        ("7.   picons-8.0W......2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-8.0W_2032024.sh -O - | /bin/sh"),
        ("8.   picons-4.0W......2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-4.0W_2032024.sh -O - | /bin/sh"),
        ("9.   picons-1.0W-0.8W_2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-1.0W-0.8W_2032024.sh -O - | /bin/sh"),
        ("10.  picons-1.9E......2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-1.9E_2032024.sh -O - | /bin/sh"),
        ("11.  picons-7.0E......2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-7.0E_2032024.sh -O - | /bin/sh"),
        ("12.  picons-9.0E......2832024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-9.0E_2832024.sh -O - | /bin/sh"),
        ("13.  picons-13.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-13.0E_2032024.sh -O - | /bin/sh"),
        ("14.  picons-16.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-16.0E_2032024.sh -O - | /bin/sh"),
        ("15.  picons-19.2E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-19.2E_2032024.sh -O - | /bin/sh"),
        ("16.  picons-21.5E.....2832024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-21.5E_28032024.sh -O - | /bin/sh"),
        ("17.  picons-23.5E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-23.5E_2032024.sh -O - | /bin/sh"),
        ("18.  picons-26.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-26.0E_2032024.sh -O - | /bin/sh"),
        ("19.  picons-39.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-39.0E_2032024.sh -O - | /bin/sh"),
        ("20.  picons-42.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-42.0E_2032024.sh -O - | /bin/sh"),
        ("21.  picons-45.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-45.0E_2032024.sh -O - | /bin/sh"),
        ("10.  picons-46.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-46.0E_2032024.sh -O - | /bin/sh"),
        ("11.  picons-51.5E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-51.5E_2032024.sh -O - | /bin/sh"),
        ("12.  picons-52.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-52.0E_2032024.sh -O - | /bin/sh"),
        ("13.  picons-53.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-53.0E_2032024.sh -O - | /bin/sh"),
        ("14.  picons-54.9E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-54.9E_2032024.sh -O - | /bin/sh"),
        ("15.  picons-62.0E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-62.0E2032024.sh -O - | /bin/sh"),
        ("16.  picons-68.5E.....2032024", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-68.5E_2032024 -O - | /bin/sh"),
        ("17.  picons_NilSat.........8W", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-Nilsat-8w-01032024.sh -O - | /bin/sh"),
        ("18.  picons_NilSat-8W.....26E", "wget https://raw.githubusercontent.com/Ham-ahmed/picons/main/picons-Nilsat-8w-26e_01032024.sh -O - | /bin/sh"),
    ],
    "16. Tools": [
        ("1.   astra-sm-arm....0.2", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/astra-sm_0.2-r0.sh -O - | /bin/sh"),
        ("2.   astra_config...0507", "wget https://raw.githubusercontent.com/Ham-ahmed/bo-snia/main/astra_config_050724.sh -O - | /bin/sh"),
        ("3.   opdboot............", "wget https://gitlab.com/eliesat/extensions/-/raw/main/opdboot/opdboot.sh -O - | /bin/sh"),
        ("4.   opkg-tools.........", "wget https://gitlab.com/eliesat/extensions/-/raw/main/opkg-tools/opkg-tools.sh -O - | /bin/sh"),
        ("5.   oscam-status.......", "wget https://gitlab.com/eliesat/extensions/-/raw/main/oscam-status/oscam-status.sh -O - | /bin/sh"),
        ("6.   plutotv............", "wget https://raw.githubusercontent.com/Ham-ahmed/Novaler/main/ipaudioplus-py3.9_4.1-r0_all.sh -O - | /bin/sh"),
        ("7.   xml update.........", "wget opkg install enigma2-plugin-systemplugins-xmlupdate -O - | /bin/sh"),
        ("8.   bitrate2.0.........", "wget https://gitlab.com/eliesat/extensions/-/raw/main/bitrate/bitrate.sh -O - | /bin/sh"),
        ("9.   quarter-pounder....", "wget https://gitlab.com/eliesat/extensions/-/raw/main/quarter-pounder/quarter-pounder.sh -O - | /bin/sh"),
        ("10.  arabicsavior.......", "wget https://gitlab.com/eliesat/extensions/-/raw/main/arabic-savior/arabicsavior.sh -O - | /bin/sh"),
        ("11.  bitrate-ahmedriad..", "wget https://gitlab.com/eliesat/extensions/-/raw/main/bitrate/bitrate-mod-ariad.sh -O - | /bin/sh"),
        ("12.  permanentclock.....", "wget opkg install enigma2-plugin-extensions-permanentclock -O - | /bin/sh"),
        ("13.  service_app........", "wget opkg install enigma2-plugin-systemplugins-serviceapp -O - | /bin/sh"),
        ("14.  service_app........", "wget https://raw.githubusercontent.com/Ham-ahmed/HAmed-Scripts/main/NewVirtualKeyBoard_sub.sh -O - | /bin/sh"),
        ("15.  New-Sherlockmod....", "wget https://raw.githubusercontent.com/biko-73/Sherlockmod/main/installer.sh -O - | /bin/sh"),
        ("16.  internet-speed-test", "wget https://raw.githubusercontent.com/Ham-ahmed/Secript-Panel/main/internet-speed-test-1.7.sh -O - | /bin/sh"),
    ],
    "17. Multiboot": [
        ("1.   neoboot..........9.65", "wget https://raw.githubusercontent.com/Ham-ahmed/212/refs/heads/main/neoboot-v9.65.sh -O - | /bin/sh"),
        ("2.   opdboot...........3.1", "wget https://raw.githubusercontent.com/Ham-ahmed/1New-P/main/opdboot-v3.1.sh -O - | /bin/sh"),
        ("3.   multiboot-flashonline", "wget https://gitlab.com/eliesat/extensions/-/raw/main/multiboot-flashonline/multiboot-flashonline.sh -O - | /bin/sh"),
    ],
    "18. remove": [
        ("1.   aglare_Skin-remove...", "wget https://raw.githubusercontent.com/Ham-ahmed/Remove/main/aglare_remove.sh -O - | /bin/sh"),
        ("2.   aglarepli-Skin_remove", "wget https://raw.githubusercontent.com/Ham-ahmed/Remove/main/aglarepli_remove.sh -O - | /bin/sh"),
        ("3.   Crash-logo...........", "wget https://gitlab.com/eliesat/scripts/-/raw/main/remove/_remove-crash-logs.sh -O - | /bin/sh"),
    ],
    "19. Bootlogo All": [
        ("1.   bootlogoswapper", "wget https://gitlab.com/eliesat/extensions/-/raw/main/bootlogoswapper/bootlogoswapper-eliesat-special-edition.sh -O - | /bin/sh"),
        ("2.   Egami-logo.....", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-egami.sh -O - | /bin/sh"),
        ("3.   Egami-logo.....", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-novaler.sh"),
        ("4.   openspa-logo...", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openspa.sh -O - | /bin/sh"),
        ("5.   pure2-logo.....", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-pure2.sh -O - | /bin/sh"),
        ("6.   openvix-logo...", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openvix.sh -O - | /bin/sh"),
        ("7.   openvix-logo...", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openvix.sh -O - | /bin/sh"),
        ("8.   openvix-logo...", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openfix.sh -O - | /bin/sh"),
        ("9.   openatv-logo...", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openatv.sh -O - | /bin/sh"),
        ("10.  openbh-logo....", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openblackhole.sh -O - | /bin/sh"),
        ("11.  opendroid-logo.", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-opendroid.sh -O - | /bin/sh"),
        ("12.  openeight-logo.", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openeight.sh -O - | /bin/sh"),
        ("13.  openhdf-logo...", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openhdf.sh -O - | /bin/sh"),
        ("14.  opennfr-logo...", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-opennfr.sh -O - | /bin/sh"),
        ("15.  openpli-logo...", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-openpli.sh -O - | /bin/sh"),
        ("16.  pkteam-logo....", "wget https://gitlab.com/eliesat/display/-/raw/main/n-image/bootlogos-n-pkteam.sh -O - | /bin/sh"),
    ],
    "20. Fix-IT": [
        ("1.   fix-atv-softcam........", "wget https://gitlab.com/eliesat/scripts/-/raw/main/all/_fix-atv-softcam-restart.sh -O - | /bin/sh"),
        ("2.   fix-xtraevent-place....", "wget https://gitlab.com/eliesat/scripts/-/raw/main/all/_fix-xtraevent-download-place.sh -O - | /bin/sh"),
        ("3.   fix-ipk-package-install", "wget https://gitlab.com/eliesat/scripts/-/raw/main/all/_fix-ipk-package-installation.sh -O - | /bin/sh"),
        ("4.   Xtraevent..............", "wget https://gitlab.com/eliesat/scripts/-/raw/main/all/_fix-xtraevent-download-place.sh -O - | /bin/sh"),
    ],
    }
        self.current_sub_menu = []
        self.focus = "main_menu"

        self["main_menu"] = MenuList(self.main_menu)
        self["sub_menu"] = MenuList(self.current_sub_menu)
        self["status"] = Label("Select a category to view items")
        self["key_red"] = Button("Exit")
        self["key_green"] = Button("Select")
        self["key_yellow"] = Button("Update Plugin")
        self["key_blue"] = Button("Restart Enigma2")
        self["background1"] = Pixmap()
        self["ip_address"] = Label(self.get_router_ip())

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {
                "ok": self.handle_ok,
                "left": self.focus_main_menu,
                "right": self.focus_sub_menu,
                "red": self.close,
                "green": self.execute_item,
                "yellow": self.update_plugin,
                "blue": self.restart_enigma2,
                "up": self.navigate_up,
                "down": self.navigate_down,
                "cancel": self.close,
            },
            -1,
        )

        self["main_menu"].onSelectionChanged.append(self.on_main_menu_selection_changed)

    def focus_main_menu(self):
        self.focus = "main_menu"
        self["main_menu"].selectionEnabled(1)
        self["sub_menu"].selectionEnabled(0)

    def focus_sub_menu(self):
        if self.current_sub_menu:
            self.focus = "sub_menu"
            self["main_menu"].selectionEnabled(0)
            self["sub_menu"].selectionEnabled(1)

    def handle_ok(self):
        if self.focus == "main_menu":
            self.load_sub_menu()
        elif self.focus == "sub_menu":
            self.execute_item()

    def load_sub_menu(self):
        selected = self["main_menu"].getCurrent()
        if selected and selected in self.sub_menus:
            self.current_sub_menu = [item[0] for item in self.sub_menus[selected]]
            self["sub_menu"].setList(self.current_sub_menu)
            self["status"].setText(f"Selected category: {selected}")
            self.focus_sub_menu()

    def on_main_menu_selection_changed(self):
        selected = self["main_menu"].getCurrent()
        if selected and selected in self.sub_menus:
            self.current_sub_menu = [item[0] for item in self.sub_menus[selected]]
            self["sub_menu"].setList(self.current_sub_menu)
            self["status"].setText(f"Showing items for: {selected}")
        else:
            self.current_sub_menu = []
            self["sub_menu"].setList(self.current_sub_menu)
            self["status"].setText("No items available for this category")

    def navigate_up(self):
        if self.focus == "main_menu":
            self["main_menu"].up()
        elif self.focus == "sub_menu":
            self["sub_menu"].up()

    def navigate_down(self):
        if self.focus == "main_menu":
            self["main_menu"].down()
        elif self.focus == "sub_menu":
            self["sub_menu"].down()

    def execute_item(self):
        if self.focus == "sub_menu":
            selected = self["sub_menu"].getCurrent()
            if selected:
                for item in self.sub_menus.get(self["main_menu"].getCurrent(), []):
                    if item[0] == selected:
                        command = item[1]
                        self.session.open(ProgressScreen, command, selected)
                        break

    def update_plugin(self):
        update_command = "wget https://gitlab.com/h-ahmed/Panel/-/raw/main/MagicPanel/MagicPanel-install.sh -O - | /bin/sh"
        self.session.open(ProgressScreen, update_command, "Update Plugin")

    def restart_enigma2(self):
        os.system("killall -9 enigma2")

    def get_router_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except socket.error:
            return "IP not available"

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="Magic Panel v5",
            description="Addon plugin For Enigma2",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon=PLUGIN_ICON,
            fnc=lambda session, **kwargs: session.open(MagicPanel),
        ),
    ]



