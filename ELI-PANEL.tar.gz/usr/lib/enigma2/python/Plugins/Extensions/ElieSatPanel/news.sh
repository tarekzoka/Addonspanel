#!/bin/sh

DATE="$(date +%a.%d.%b.%Y)"
echo ">>>Eliesatpanel $DATE<<<"
sleep 1
echo ">>>zoukmosbeh-lebanon<<<"

echo "> no new news "
sleep 3

echo
echo ">>> Eliesat enjoy <<<"

